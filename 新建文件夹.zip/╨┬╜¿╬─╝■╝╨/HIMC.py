# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 18:29:57 2018

@author: Administrator
"""
import pandas as pd
import numpy as np
#read csv
pd.set_option('display.max_colwidth',1000)
data=pd.read_csv('COMAP_RollerCoasterData_2018.csv',encoding='gbk')
data= data.iloc[:,0:19]
#research the relationship between park and collerster
len(set(data['Park']))
data['Park'].count()
s1=data.groupby('Park')
s=s1.count()
s=s['Name']
s.argmax()
#research the relationship between Region and roller coaster
s=data.groupby('Geographic Region')
s=s.count()
##research the relationship between roller coaster type and roller coaster

s=data.groupby('Type')
s=s.count()
s=s["Name"]
##research the relationship between open year and roller coaster

num=data.iloc[:,9:19]
num['Year/Date Opened']=2018-num['Year/Date Opened']
num['Year/Date Opened'].describe()
##research the relationship between height and roller coaster

height=num['Height (feet)']
height.hist(bins=10)
num['Height (feet)'].describe()
num['Drop (feet)'].count()
#To add the score of roller coaster 
target=pd.read_csv('target.csv')
roller_name=list(target['Roller coaster'])
target=target.iloc[:,0:4]
names=[]
i=0
for name in roller_name[1:]:
    s=name.split(',')
    names.append(s[0])
    
target['Rollercoaster']=pd.Series(names)
len(set(names)&set(data['Name']) )  
roller_coaster=list(set(names)&set(data['Name']))
columns=['Name','Construction','Type','Year/Date Opened', 'Height (feet)', ' Speed (mph)', 'Length (feet)','Number of Inversions','Duration (min:sec)']

    
roller1=data[columns]
roller1['Year/Date Opened']=2018-roller1['Year/Date Opened']
ROLL=pd.DataFrame()
for i in list(roller_coaster):
    t=roller1[roller1["Name"]==i]
    ROLL=ROLL.append(t)
ROLL.index=range(len(ROLL))
dele=list(set(names)-(set(names)&set(data['Name'])))
del1=pd.DataFrame()
for i in roller_coaster:
    t=target[target['Rollercoaster']==i]
    del1=del1.append(t)
len(del1)
#combine the feature set and the target set
del1.sort_values('Rollercoaster',inplace=True)
del1.index=range(len(del1))
ROLL.sort_values('Name',inplace=True)
ROLL.index=range(len(ROLL))
ROLL['score']=del1['Score']
#ROLL.to_csv()
#save ROLL
############
###deal non-numerical feture
#
#from sklearn.preprocessing import OneHotEncoder
ROLL.Type
map1={'Sit Down':0,'Wing':1,'Inverted':1,"Flying":1}
f=lambda x: map1.get(x,x)
len(list(ROLL.Type.map(f)))
tyype=ROLL.Type.map(f)
ROLL.Type=tyype
map2={"Steel":0,'Steel ':0,"Wood":1}
f2=lambda x: map2.get(x,x)
ROLL.Construction=ROLL.Construction.map(f2)
ROLL 
X_columns=['Construction', 'Type', 'Year/Date Opened', 'Height (feet)',
       ' Speed (mph)', 'Length (feet)', 'Number of Inversions',
       'Duration (min:sec)']
X=ROLL[X_columns]
y=ROLL['score']
#deal with the null value
X['Height (feet)'].fillna(X['Height (feet)'].mean(),inplace=True)

X[' Speed (mph)'].fillna(X[' Speed (mph)'].mean(),inplace=True)
X['Length (feet)'].fillna(X['Length (feet)'].mean(),inplace=True)
X['Number of Inversions'].fillna(X['Number of Inversions'].mean(),inplace=True)
def t2s(t):
    try:    
        m,s = t.strip().split(":")
        return int(m) * 60 + int(s)
    except:
        return np.nan
X['Duration (min:sec)']=X['Duration (min:sec)'].apply(t2s)
X['Duration (min:sec)'].fillna(int(X['Duration (min:sec)'].mean()),inplace=True)


##########Linear model
from sklearn.linear_model import LinearRegression
linreg=LinearRegression()
linreg.fit(X,y)
#回归系数：[ 6.29887824e-03,  1.94758739e-01, -9.22221939e-03, -1.14934876e-03,
#        2.85191263e-03,  5.70798002e-05, -5.09092738e-02, -2.78728495e-04])
#test set
roller1=data[columns]
roller1['Year/Date Opened']=2018-roller1['Year/Date Opened']
#data preprocessing
map1={'Sit Down':0,'Wing':1,'Inverted':1,"Flying":1,"Stand Up":1,"Suspended":1,"Steel":1,"Wood":1}
f=lambda x: map1.get(x,x)
len(list(roller1.Type.map(f)))
tyype=roller1.Type.map(f)
roller1.Type=tyype
map2={"Steel":0,'Steel ':0,"Wood":1}
f2=lambda x: map2.get(x,x)
roller1.Construction=roller1.Construction.map(f2)
#roller1 
#################
roller1['Height (feet)'].fillna(roller1['Height (feet)'].mean(),inplace=True)
roller1[' Speed (mph)'].fillna(roller1[' Speed (mph)'].mean(),inplace=True)
roller1['Length (feet)'].fillna(roller1['Length (feet)'].mean(),inplace=True)
roller1['Number of Inversions'].fillna(roller1['Number of Inversions'].mean(),inplace=True)
def t2s(t):
    try:    
        m,s = t.strip().split(":")
        return int(m) * 60 + int(s)
    except:
        return np.nan
roller1['Duration (min:sec)']=roller1['Duration (min:sec)'].apply(t2s)
roller1['Duration (min:sec)'].fillna(int(roller1['Duration (min:sec)'].mean()),inplace=True)
X_columns=['Construction', 'Type', 'Year/Date Opened', 'Height (feet)',
       ' Speed (mph)', 'Length (feet)', 'Number of Inversions',
       'Duration (min:sec)']
X_p=roller1[X_columns]
predict=linreg.predict(X_p)

data['Socre']=pd.DataFrame(predict)
data.sort_values('Socre',inplace=True)
data.index=range(len(data))
top10=list(data.tail(10).Name)
top10.reverse()
top10score=list(data.tail(10).Socre)
top10score.reverse()
top10park=list(data.tail(10).Park)
top10park.reverse()
result=pd.DataFrame([top10,top10park,top10score]).T
result.columns=["name","park","score"]
###########回归树
from sklearn.tree import DecisionTreeRegressor

#http://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeRegressor.html#sklearn.tree.DecisionTreeRegressor

XX = X.values
yy = y.values
#XX_p=X_p.values
reg = DecisionTreeRegressor(max_depth=3)   #max_depth设置树深
reg.fit(XX, yy)   #参考官网attributes部分了解建模后得到的各种属性:树，使用的特征及特征重要性
result2=reg.predict(X_p.values)
data['Socre2']=pd.DataFrame(result2)
data.sort_values('Socre',inplace=True)
data.index=range(len(data))
#tree visualization
from IPython.display import Image  
from sklearn import tree
import pydotplus 
dot_data = tree.export_graphviz(reg, out_file=None, 
                         feature_names=X.columns,  
                         class_names=['y'],  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = pydotplus.graph_from_dot_data(dot_data)  
Image(graph.create_png())
# plt.savefig('./figures/tree_regression.png', dpi=300)



#水平红线表示c值，竖直红线表示特征列选择的切分点

